from django.db import models

class AramaSonucu(models.Model):
    konu = models.CharField(max_length=255)  # Konu başlığı
    uzanti = models.CharField(max_length=10)  # Dosya türü (PDF, DOCX vb.)
    search_url = models.URLField()  # Arama sonucunun URL'si
    tarih = models.DateTimeField(auto_now_add=True)  # Eklenme tarihi

    class Meta:
        ordering = ['-tarih']  # Stack mantığı: En son eklenen en önce gelir

    def __str__(self):
        return f"{self.konu} - {self.uzanti} ({self.tarih.strftime('%Y-%m-%d %H:%M:%S')})"

    @staticmethod
    def push(konu, uzanti, search_url):
        """Stack'e yeni bir veri ekle."""
        arama_sonucu = AramaSonucu(konu=konu, uzanti=uzanti, search_url=search_url)
        arama_sonucu.save()
        return arama_sonucu

    @staticmethod
    def pop():
        """Stack'ten en son eklenen veriyi çıkar."""
        son_veri = AramaSonucu.objects.first()  # Tarihe göre sıralı olduğu için ilk kayıt en yenisi
        if son_veri:
            son_veri.delete()
            return son_veri
        return None

    @staticmethod
    def peek():
        """Stack'in en üstündeki veriyi görüntüle."""
        return AramaSonucu.objects.first()

    @staticmethod
    def is_empty():
        """Stack'in boş olup olmadığını kontrol et."""
        return not AramaSonucu.objects.exists()

    @staticmethod
    def get_all():
        """Tüm stack verilerini listele."""
        return AramaSonucu.objects.all()
