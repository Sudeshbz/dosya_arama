from django.shortcuts import render
from .models import AramaSonucu
import urllib.parse

def arama(request):
    # Eğer POST isteği gelirse, arama yapalım
    if request.method == "POST":
        konu = request.POST.get('konu')
        uzanti = request.POST.get('uzanti')
        if konu and uzanti:
            query = urllib.parse.quote(f"{konu} {uzanti}")
            search_url = f"https://www.google.com/search?q={query}"

            # Stack'e yeni arama ekliyoruz
            AramaSonucu.push(konu, uzanti, search_url)

            # Tüm arama sonuçlarını linked list gibi sıralı bir şekilde alıyoruz
            arama_sonuclari = AramaSonucu.get_all()

            return render(request, 'arama/sonuc.html', {'search_url': search_url, 'arama_sonuclari': arama_sonuclari})

    # Stack'teki tüm verileri alalım
    arama_sonuclari = AramaSonucu.get_all()
    
    return render(request, 'arama/arama.html', {'arama_sonuclari': arama_sonuclari})
